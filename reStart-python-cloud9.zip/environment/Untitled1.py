"""
Your module description
"""

import math

print(math.floor(4.5))

 

from math import floor

print(floor(4.5))