"""
Your module description
"""
a=int(input("Enter the number: "))



if ((a/2)==True):

    print(f"{a} is even")

else:

    print(f"{a} is odd")