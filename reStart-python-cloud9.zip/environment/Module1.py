"""
Calling functions from Module1 into Module2
"""
x=888
def add(a,b):
    print("the sum:",a+b)
    
def product(a,b):
        print("the product:",a*b)
        
def sub(a,b):
    print("the sub:",a-b)
        

