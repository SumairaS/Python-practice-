"""
Create a Python program that checks if a given number is positive, negative, or zero and prints an appropriate message.
"""
a=int(input("Enter the number: "))



if(a>0):

    print(f"{a} is positive number")
    
elif(a<0):
    print(f"{a} is negative number")

elif(a==0):

    print(f"{a} is zero")
    
