"""
Hello World
Sumaira's 1st PY code
"""
print("Hello world \n you are a good coder")
a=10
b=20
print("the sum:",(a+b))

the_world_is_flat=True
if the_world_is_flat :
    {
        print("this world is flat")
    }