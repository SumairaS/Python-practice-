"""
Your module description
"""

import math

absolute = -5.999 

floor_test = 198.42

result1 = math.fabs(absolute) 

result2 = math.floor(floor_test)

print(result1, " is the absolute value of ", absolute) 

print(result2, " is the flow of ", floor_test)