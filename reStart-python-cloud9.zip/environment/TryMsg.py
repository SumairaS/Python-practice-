"""
Your module description
"""
try:
    # Your code that might cause an exception
    # For example:
    x = 1 / 0
except Exception as e:
    # Print the exception message
    print(f"An exception occurred: {str(e)}")