"""
List tuple both are same only diffrence is of mutability
"""
Dish=['cake','tea','dal']
Dish[0]='roti'
print(Dish)

print(type(Dish))

sampleOfTuple=("alpha","beta","gamma")
print(type(sampleOfTuple))
sampleOfTuple[1]="oman"