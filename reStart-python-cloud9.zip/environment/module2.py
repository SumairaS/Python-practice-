"""
Your module description
"""
import Module1
print(Module1.x)
Module1.add(10,23)
Module1.product(10,20)