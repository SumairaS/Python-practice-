"""
Learning the use of Functions in Python
"""
"""
Types of Functions:
             1.Built-in           2. User-defined 
    
"""
def ft1(n):
    print("n",n+n,"m")
    
ft1("h")

def add(x,y,c):
    return x+y,c
    
add(1,2,"goo")
