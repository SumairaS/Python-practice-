"""
Calling functions from Module1 into Module2
"""
"""Simply calling the whole Module"""
import Module1
print(Module1.x)
Module1.add(10,23)
Module1.product(10,20)


import Module1 as m
print(m.x)

"""calling only selected/ all functions FROM a module """
from Module1 import add,sub,x
print(x)
sub(10,20)

from Module1 import*

