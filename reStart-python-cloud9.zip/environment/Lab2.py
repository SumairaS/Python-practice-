"""
Numeric Data Types

int
flot
complex
bool
str
bytes
bytearry
range
listlong
tuple/dict set
None
frozenset
memoryview"""





""" importing data Reserved and from other file"""

import keyword
keyword.kwlist
print(keyword.kwlist)

c=5
import Lab1
Lab1.a
print(c+Lab1.a)

